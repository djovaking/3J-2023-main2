<?php

namespace App\core;
class Security{
    public static function isConnected(): bool
    {
        return false;
    }

}