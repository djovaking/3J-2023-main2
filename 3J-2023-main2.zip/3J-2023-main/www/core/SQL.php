<?php
namespace App\core;
class SQL{

    private $pdo;
    private $table;

    public function __construct(){
        try{
            $this->pdo = new \PDO(DB_DRIVER.":host=".DB_HOST.";dbname=".DB_NAME.";port=".DB_PORT, DB_USER, DB_PWD);
        }catch (\Exception $e){
            die("Erreur SQL : ".$e->getMessage());
        }
        $classExploded = explode("\\", get_called_class());
        $this->table = DB_PREFIX.strtolower(end($classExploded));
    }

    public function save():void
    {
        $columns = get_object_vars($this);
        $columnsToDelete = get_class_vars(get_class());
        $columns = array_diff_key($columns, $columnsToDelete );

        if($columns["id"] == -1){
            unset($columns["id"]);
            $queryPrepared = $this->pdo->prepare("INSERT INTO ".$this->table." ( ".implode(", ", array_keys($columns))." ) ".
                " VALUES (:".implode(",:", array_keys($columns)).")");

            $queryPrepared->execute($columns);
        }

        /*
         * Pour la prochaine fois (le 16 Mai) réalisez le code permettant d'utiliser
         * la methode SAVE aussi pour réaliser un UPDATE SQL, Si l'ID est différent
         * de -1 il faut partir du principe que c'est un update
         */

    }

}