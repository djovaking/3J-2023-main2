<?php

define("DB_NAME", "esgi");
define("DB_DRIVER", "pgsql");
define("DB_HOST", "database");
define("DB_PORT", "5432");
define("DB_USER", "esgi");
define("DB_PWD", "Test1234");
define("DB_PREFIX", "esgi_");