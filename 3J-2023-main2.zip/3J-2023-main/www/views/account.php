<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Mon site MVC</title>
    <meta name="description" content="mon super site en MVC from scratch">
</head>
<body>
<h1>Comptes</h1>


<!-- la vue  -->
<?php include $this->view; ?>

</body>
</html>
