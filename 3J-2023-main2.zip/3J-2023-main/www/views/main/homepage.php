<h2>Page d'accueil</h2>
<h3>Bonjour <?= $pseudo ?> <?= $lastname ?></h3>

